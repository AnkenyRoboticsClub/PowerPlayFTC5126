package org.firstinspires.ftc.teamcode;


public class SimpleTele {

    // todo: write your code here
}